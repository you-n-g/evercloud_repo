#coding=utf-8

import json
from django.conf import settings
from django.http import HttpResponse

